from django.apps import AppConfig


class BiServersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bi_servers'
